<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://phpdocs.com
 * @since      1.0.0
 *
 * @package    Customs_Ads_For_Post
 * @subpackage Customs_Ads_For_Post/public/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
