<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://phpdocs.com
 * @since      1.0.0
 *
 * @package    Customs_Ads_For_Post
 * @subpackage Customs_Ads_For_Post/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Customs_Ads_For_Post
 * @subpackage Customs_Ads_For_Post/includes
 * @author     Muhammad Afzal <testing@gail.com>
 */
class Customs_Ads_For_Post_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
