<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       https://phpdocs.com
 * @since      1.0.0
 *
 * @package    Customs_Ads_For_Post
 * @subpackage Customs_Ads_For_Post/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Customs_Ads_For_Post
 * @subpackage Customs_Ads_For_Post/includes
 * @author     Muhammad Afzal <testing@gail.com>
 */
class Customs_Ads_For_Post_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'customs-ads-for-post',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
