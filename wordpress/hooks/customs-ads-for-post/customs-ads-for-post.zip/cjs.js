$(document).ready(function () {
    console.log("Welcome to Our Website");
    alert("Welcome to Our Website");
});