<?php

/**
 * Fired during plugin activation
 *
 * @link       https://phpdocs.com
 * @since      1.0.0
 *
 * @package    Custom_Quote_Form
 * @subpackage Custom_Quote_Form/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Custom_Quote_Form
 * @subpackage Custom_Quote_Form/includes
 * @author     Muhammad Afzal <testing@gail.com>
 */
class Custom_Quote_Form_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
