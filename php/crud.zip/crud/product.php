<?php require_once("helper/auth_helper.php"); ?>
<?php require_once("template/header.php"); ?>

    <!--Container Area Start-->
    <div class="container-fluid">
        <div class="row my-2">
            <div class="col-12 text-center">
                <h2>Product Management</h2>
            </div>
        </div>
    </div>
    <!--Create Grid for Users End
    </div>
    <!--Container Area End-->
<?php require_once("template/footer.php"); ?>